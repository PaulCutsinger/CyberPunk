/* eslint-disable  func-names */
/* eslint quote-props: ["error", "consistent"]*/
/**
 * This sample demonstrates a simple skill built with the Amazon Alexa Skills
 * nodejs skill development kit.
 * This sample supports multiple lauguages. (en-US, en-GB, de-DE).
 * The Intent Schema, Custom Slots and Sample Utterances for this skill, as well
 * as testing instructions are located at https://github.com/alexa/skill-sample-nodejs-fact
 **/

'use strict';

const Alexa = require('alexa-sdk');

const APP_ID = undefined;  // TODO replace with your app ID (OPTIONAL).

const languageStrings = {
    'en-US': {
        translation: {
            LOCATIONS: {
              //alias (what the person said) : official_name (what they want)
              'immortal fountain':'immortal_fountain',
              'fountain':'immortal_fountain',
              'watts':'immortal_fountain',
              'perpetual campfire':'perpetual_campfire',
              'campfire':'perpetual_campfire',
              'grim':'perpetual_campfire',
              'grimm':'perpetual_campfire',
              'beyond':'the_beyond',
              'the beyond':'the_beyond',
              'daft staircase':'daft_staircase',
              'shop':'meta_shop',
              'shop keeper':'meta_shop',
              'kiosk shop':'meta_shop',
              'meta circle':'meta_circle',
              'gate 1':'immortal_fountain',
              'gate 2':'perpetual_campfire',
            },
            TUNES: {
              's i m o n':'song_of_simon',
              's a m':'song_of_sam',
              's a m a n t h a':'song_of_sam',
              'p a u l':'song_of_paul',
              'j u d y':'song_of_judy',
              'c d e g a':'major_pentatonic',
              'c sharp d e g a':'sharp_major_pentatonic',
            }
            SKILL_NAME: 'American Space Facts',
            GET_FACT_MESSAGE: "Here's your fact: ",
            HELP_MESSAGE: 'You can say tell me a space fact, or, you can say exit... What can I help you with?',
            HELP_REPROMPT: 'What can I help you with?',
            STOP_MESSAGE: 'Goodbye!',
        },
    },
};

const handlers = {
    'LaunchRequest': function () {
        this.emit('ExploreIntent');
    },
    'ExploreIntent': function () {
        var location =  this.event.request.intent.slots.Location;
        var speechOutput;
        if(isValidSlot(location)){
          speechOutput="Headed to "+location;
        }
        speechOutput="no, we're not doing that";
        this.emit(':ask', speechOutput);
    },
    'AMAZON.HelpIntent': function () {
        const speechOutput = this.t('HELP_MESSAGE');
        const reprompt = this.t('HELP_MESSAGE');
        this.emit(':ask', speechOutput, reprompt);
    },
    'AMAZON.CancelIntent': function () {
        this.emit(':tell', this.t('STOP_MESSAGE'));
    },
    'AMAZON.StopIntent': function () {
        this.emit(':tell', this.t('STOP_MESSAGE'));
    },
    'SessionEndedRequest': function () {
        this.emit(':tell', this.t('STOP_MESSAGE'));
    },
};

function isValidSlot(slot){
    if (slot && slot.value) {
      //we have a value in the slot
      return true
    }
    return false
}

function normalizeSlot(slot){
    return slot.value.toLowerCase();
}

exports.handler = (event, context) => {
    const alexa = Alexa.handler(event, context);
    alexa.APP_ID = APP_ID;
    // To enable string internationalization (i18n) features, set a resources object.
    alexa.resources = languageStrings;
    alexa.registerHandlers(handlers);
    alexa.execute();
};
